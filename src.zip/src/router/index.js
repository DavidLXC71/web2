import { createRouter, createWebHashHistory } from 'vue-router'
import Login from '../views/Login.vue'
import MainBox from '../views/MainBox.vue'
import RoutesConfig from './config'
import store from '../store/index'

const routes = [
  {
    path: "/login",
    name: "login",
    component: Login
  },
  {
    path: "/mainbox",
    name: "mainbox",
    component: MainBox

  }
  //后续动态添加mainbox的嵌套路由，根据权限
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

router.beforeEach((to, from, next) => {
  if (to.name === "login") {
    next()
  } else {
    //如果授权(已经登录过了) next()
    //未授权, 重定向到login
    if (!localStorage.getItem("token")) {
      next({
        path: "/login"
      })
    } else {
      // 对vuex中的登录标志为进行判断(第一次登录位false)
      if (!store.state.isGetterRouter) {
        // 删除所有的嵌套路由(直接删除mainbox)
        router.removeRoute('mainbox')// 重新配置mainbox
        ConfigRouter()// 配置动态路由以及设置登录标志位
        next({// 让路由重新走一遍
          path: to.fullPath
        })
      } else {
        next()
      }
    }
  }
})

const ConfigRouter = () => {
  // 判断当前主路由中是否存在mainbox
  if (!router.hasRoute("mainbox")) {
    router.addRoute({
      path: "/mainbox",
      name: "mainbox",
      component: MainBox
    })
  }
  /*
    对配置好的路由页面数据(数组)进行循环遍历,动态添加到项目的主盒子下面
  */
  RoutesConfig.forEach(item => {
    checkPermission(item) && router.addRoute("mainbox", item)
  })

  //改变isGetterRouter =  true
  store.commit("changeGetterRouter", true)
}

const checkPermission = (item) => {
  if (item.requireAdmin) {
    return store.state.userInfo.role === 1
  }
  return true
}


export default router
