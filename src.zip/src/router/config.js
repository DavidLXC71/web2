import Center from '../views/center/Center.vue'
import Home from '../views/home/Home.vue'
import NewsList from '../views/news_manage/NewsList.vue'
import NewsAdd from '../views/news_manage/NewsAdd.vue'
import UserAdd from '../views/user_manage/UserAdd.vue'
import UserList from '../views/user_manage/UserList.vue'
import ProductList from '../views/product_manage/ProductList.vue'
import ProductAdd from '../views/product_manage/ProductAdd.vue'
import NotFound from '../views/notfound/NotFound.vue'

const routes = [
    {
        path: "/index",
        component: Home
    },
    {
        path: "/center",
        component: Center

    },
    {
        path: "/user_manage/adduser",
        component: UserAdd,
        requireAdmin: true

    },
    {
        path: "/user_manage/userlist",
        component: UserList,
        requireAdmin: true
    },
    {
        path: "/news_manage/newslist",
        component: NewsList
    },
    {
        path: "/news_manage/addnews",
        component: NewsAdd
    },
    {
        path: "/product_manage/productlist",
        component: ProductList
    },
    {
        path: "/product_manage/addproduct",
        component: ProductAdd
    },
    {
        path: "/",
        redirect: "/index"
    },
    {
        path: "/:pathMatch(.*)*",
        name: "Notfound",
        component: NotFound
    }

]

export default routes
