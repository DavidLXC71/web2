<template>
   <el-empty description="朱朱 走丢了" />
</template>

<script>
export default {

}
</script>

<style>

</style>
