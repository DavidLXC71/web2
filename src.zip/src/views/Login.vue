<template>
  <div>
    <div class="formContainer">
      <h2 class="title">网站管理系统</h2>
      <el-form
        ref="loginFormRef"
        :model="loginForm"
        status-icon
        :rules="loginRules"
        label-width="80px"
        class="demo-ruleForm"
      >
        <el-form-item label="用户名" prop="username">
          <el-input v-model="loginForm.username" autocomplete="off" />
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input
            v-model="loginForm.password"
            type="password"
            autocomplete="off"
          />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitForm()">登录</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script setup>
import { reactive, ref } from "vue";
import { useRouter } from "vue-router";
import axios from "axios";
import { ElMessage } from "element-plus";
import { useStore } from "vuex";

const store = useStore();

const loginForm = reactive({
  username: "",
  password: "",
}); //表单绑定的响应式对象

const loginFormRef = ref(); //表单的引用对象

const loginRules = reactive({
  username: [
    {
      required: true,
      message: "请输入用户名",
      trigger: "blur",
    },
  ],
  password: [
    {
      required: true,
      message: "请输入密码",
      trigger: "blur",
    },
  ],
});
const router = useRouter();

const submitForm = () => {
  loginFormRef.value.validate((valid) => {
    if (valid) {
      axios.post("/adminapi/user/login", loginForm).then((res) => {
        if (res.data.ActionType === "OK") {
          store.commit("changeUserInfo", res.data.data);
          store.commit("changeGetterRouter", false);
          router.push("/index");
        } else {
          ElMessage.error("用户名和密码不匹配哦");
        }
      });

      //router.push("/index")
    }
  });
};
</script>

<style lang="scss" scoped>
.title {
  color: black;
  margin-top: 20px;
  margin-bottom: 40px;
}

.formContainer {
  width: 500px;
  height: 300px;
  position: fixed;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  border: 1px solid #53575c72;
  color: white;
  text-align: center;
  padding: 20px;
}
</style>