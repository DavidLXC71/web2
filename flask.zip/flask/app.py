from flask import Flask, request, jsonify, make_response,g
import config
from exts import db
from blueprints.admin import bp as admin_bp
from flask_migrate import Migrate
from blueprints.admin import JWT


app = Flask(__name__)
# 绑定配置文件
app.config.from_object(config)

db.init_app(app)

migrate = Migrate(app, db)

app.register_blueprint(admin_bp)

@app.before_request
def check_token():
    # 跳过登录路由的验证
    if request.path == "/adminapi/user/login" or request.path.startswith("/static/"):
        return

    token = request.headers.get('Authorization')
    if token:
        payload = JWT.verify(token)
        if isinstance(payload, str):
            return jsonify({'errCode': '-1', 'errorInfo': payload}), 401
        else:
            # 将有效的 payload 附加到全局变量 g，以便后续使用
            g.payload = payload
    else:
        return jsonify({'errCode': '-1', 'errorInfo': 'Token缺失'}), 401

@app.after_request
def refresh_token(response):
    # 检查全局变量 g 是否有有效的 payload
    if hasattr(g, 'payload'):
        new_token = JWT.generate({'_id': g.payload['sub']['_id'], 'username': g.payload['sub']['username']}, 600)
        response.headers['Authorization'] = new_token
    return response

if __name__ == '__main__':
    app.run()
