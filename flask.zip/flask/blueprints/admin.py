from flask import Blueprint, jsonify, make_response, g
from flask import request
from models import UserModel
from exts import db
from werkzeug.utils import secure_filename
import datetime
import jwt
import os
# /auth
bp = Blueprint("admin", __name__, url_prefix="/adminapi")

secret = 'david'  # 应该是一个安全的密钥

# generate参数为数值和时间，时间单位为秒
class JWT:
    @staticmethod
    def generate(value, expires):
        payload = {
            'exp': datetime.datetime.utcnow() + datetime.timedelta(seconds=expires),
            'iat': datetime.datetime.utcnow(),
            'sub': value
        }
        return jwt.encode(payload, secret, algorithm='HS256')

    @staticmethod
    def verify(token):
        if token.startswith("Bearer "):
            token = token[7:]
        try:
            payload = jwt.decode(token, secret, algorithms=['HS256'])
            return payload
        except jwt.ExpiredSignatureError:
            return 'Signature expired. Please log in again.'
        except jwt.InvalidTokenError:
            return 'Invalid token. Please log in again.'


@bp.route("/user/login", methods=['POST'])
def user_login():
    login_data = request.json
    username = login_data['username']
    password = login_data['password']
    user = UserModel.query.filter_by(username=username, password=password).first()
    if not user:
        return jsonify({"code": -1, "error": "用户名密码不匹配"})
    else:
        token = JWT.generate({'_id': user.id, 'username': user.username}, 600)
        user_data = {
            'username': user.username,
            'gender': user.gender if user.gender is not None else 0,
            'introduction': user.introduction,
            'avatar': user.avatar,
            'role': user.role
        }
        response_data = {
            'ActionType': 'OK',
            'data': user_data
        }
        response = make_response(jsonify(response_data))
        # 在响应头中添加 token
        response.headers['Authorization'] = token
        return response


@bp.route('/user/upload', methods=['POST'])
def user_upload():
    file = request.files.get('file')
    form_data = {key: value for key, value in request.form.items()}
    user_id = g.payload['sub']['_id']
    user = UserModel.query.get(user_id)
    if not user:
        return jsonify({'error': 'User not found'}), 404

    # 只有当文件存在且文件名不为空时才保存新头像
    if file and file.filename:
        filename = secure_filename(file.filename)
        file.save(os.path.join('static/avataruploads', filename))
        user.avatar = f'/avataruploads/{filename}'

    # 更新其他用户信息
    user.username = form_data.get('username', user.username)
    user.gender = form_data.get('gender', user.gender)
    user.introduction = form_data.get('introduction', user.introduction)

    db.session.commit()

    # 返回更新后的用户信息
    user_data = {
        'username': user.username,
        'gender': user.gender,
        'introduction': user.introduction,
        'avatar': user.avatar,  # 注意，如果没有上传新头像，这里会返回旧的头像路径
    }
    response_data = {
        'ActionType': 'OK',
        'data': user_data
    }

    return jsonify(response_data)

@bp.route('/user/add', methods=['POST'])
def user_add():
    # 获取表单数据和文件
    form_data = {key: value for key, value in request.form.items()}
    file = request.files.get('file')

    # 提取用户信息
    username = form_data.get('username')
    password = form_data.get('password')
    gender = form_data.get('gender')
    introduction = form_data.get('introduction')
    role = form_data.get('role')

    # 检查用户名是否已存在
    if UserModel.query.filter_by(username=username).first():
        return jsonify({'error': '用户名已存在'}), 400

    # 保存头像文件
    if file and file.filename:
        filename = secure_filename(file.filename)
        file.save(os.path.join('static/avataruploads', filename))
        avatar = f'/avataruploads/{filename}'
    else:
        avatar = '/avataruploads/default.png'  # 默认头像

    # 创建新用户对象
    new_user = UserModel(
        username=username,
        password=password,
        gender=gender,
        introduction=introduction,
        role=role,
        avatar=avatar
    )

    # 添加到数据库
    db.session.add(new_user)
    db.session.commit()

    # 返回成功响应
    return jsonify({'message': '用户添加成功'}), 201

@bp.route('/user/list', methods=['GET'])
def get_users():
    users = UserModel.query.all()
    users_data = [{
        'id': user.id,
        'username': user.username,
        'gender': user.gender,
        'introduction': user.introduction,
        'avatar': user.avatar,
        'role': user.role
    } for user in users]
    return jsonify({'data': users_data}), 200


@bp.route('/user/list/<int:user_id>', methods=['PUT'])
def edit_user(user_id):
    user = UserModel.query.get_or_404(user_id)
    data = request.json
    user.username = data.get('username', user.username)
    user.password = data.get('password', user.password)
    user.gender = data.get('gender', user.gender)
    user.introduction = data.get('introduction', user.introduction)
    user.role = data.get('role', user.role)

    db.session.commit()
    return jsonify({'message': '用户信息已更新'}), 200

@bp.route('/user/list/<int:user_id>', methods=['DELETE'])
def delete_user(user_id):
    user = UserModel.query.get_or_404(user_id)
    db.session.delete(user)
    db.session.commit()
    return jsonify({'message': '用户已删除'}), 200

@bp.route('/user/list/<int:user_id>', methods=['GET'])
def get_user(user_id):
    user = UserModel.query.get_or_404(user_id)
    user_data = {
        'id': user.id,
        'username': user.username,
        'password': user.password,  # 注意：出于安全考虑，通常不应该返回密码
        'gender': user.gender,
        'introduction': user.introduction,
        'role': user.role,
        'avatar': user.avatar
    }
    return jsonify({'data': user_data}), 200


