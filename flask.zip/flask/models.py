from exts import db


class UserModel(db.Model):
    __tablename__ = "user"
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(100), nullable=False)
    password = db.Column(db.String(200), nullable=False)
    gender = db.Column(db.Integer, nullable=False)
    introduction = db.Column(db.Text, nullable=True)
    avatar = db.Column(db.String(200), nullable=True)
    role = db.Column(db.Integer, nullable=False)
